<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('bs_special_educator_master', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->string('name', 100)->unique()->comment('Special educator type');
            $table->smallInteger('rank')->nullable()->comment('Rank (int2)');
            $table->smallInteger('status')->default(1)->comment('1 = active, 0 = inactive');

            // Audit
            $table->timestamps();
            $table->softDeletes();
            // Indexes
            $table->index(['status', 'rank']);
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('bs_special_educator_master');
    }
};
